ROSBONE MEATHEAD VST3
Author: Rosbone DSP
Date: 5/28/2026
Rev: 2.01

This VST is sample code to show how to create a Guitar amplifier effect. Compiled
EXE standalone app and the VST3 files are included if you wish to use MeatHead
without going thru the motions of building the app in Juce 7.

The included code is for a JUCE 7 Basic VST project. The project uses a PNG
image as a background. This can be removed, comment out any img code in editor.
It was built on Windows and tested in Reaper (DAW). 

The MH.png file is used as the EXE icon and is added inside of Projucer (VS tab). 

The VST creates an amplifier effect by utilizing captured IRs of amplifiers to
create input frequency response curves. The signal is passed thru the amplifier
IR, gain is added, and then the signal is passed thru a speaker IR.

The amplifier and speaker IRs use 1024 samples. The amplifier IRs are very compact
and can be run as low as 128 samples to reduce CPU utilization.

Additional stages in the amplifier model:
- Boost - Mimics the freq boosts of OD pedals.
- Thump - Adds a 150 low pass distortion.
- Air - Adds 1500 Hz high pass distortion.
- Power - Adds more post EQ distortion to emulate power amp / speaker distortion.

ISSUES:
- VST was built on MS C++ 2022 and may require MS Runtime files.
- The included VST and Exe are built using Static libraries for increased compatibility.

QUICK START HOW TO BUILD IN JUCE and Visual Studio.
1. Install JUCE 7 PROJUCER.
2. Create a BASIC PLUG-IN project. Set it to EXE and VST.
3. Edit the project details in DEBUG/RELEASE tab. Title, etc.
   Hint: In Debug, set runtime library to "Use Static Runtime".
4. If you have any images you can drag/drop to the FILE EXPLORER tab.
   These will be added to the project and accessible in your app.
   If you change a file you will need to resave the Juce project so it
   can build the new file into the project code.
5. Under the Visual studio tab you can set the program icon.
6. Save the project. You will see a wait icon as it builds the project.
   No wait icon, means you only saved some file not the whole project.
   Click on the DEBUG or RELEASE tab under EXPORTERS then select SAVE.
7. A folder will be created with many directories. There will be four files
   in the source directory. Replace them with the provided four files here. 
8. Start Visual Studio (or other) and navigate to the VS solution file.
9. Verify you are in DEBUG mode and press F5 to run. 
   Juce by default lets you build an EXE version which is much easier to debug in. 
   Easy mode is to run/debug the EXE in VS debug mode. 
10. To build the finished VST3, put VS into RELEASE mode and select BUILD from the
   main menu.
11. You will need to dig thru the VS folders of your project to find the VST3 file.
 